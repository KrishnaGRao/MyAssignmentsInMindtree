import React from "react"

const StarRating = ()=>{

    return(<>
        <div></div>
    </>)

}

export default StarRating;