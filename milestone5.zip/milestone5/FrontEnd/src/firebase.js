import firebase from "firebase"

  const config = {
    apiKey: "AIzaSyCcUv1UESWyeRWQz9fqRiVbm_kT5nK9ZMw",
    authDomain: "milestone5-78278.firebaseapp.com",
    projectId: "milestone5-78278",
    storageBucket: "milestone5-78278.appspot.com",
    messagingSenderId: "688647660382",
    appId: "1:688647660382:web:11d13bf164a74447eb25cf"
  }
  firebase.initializeApp(config);

  export default firebase;